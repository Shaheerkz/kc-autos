@props([
    'title',
    'href'
])
<a href="{{ $href }}" class="nav-link text-white">
    {{ $title }}
</a>
