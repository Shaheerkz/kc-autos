<?php $__env->startSection('content'); ?>
    <div class="notification-page">
        <div class="container">
            <div class="row justify-content-center">
                <div class="notify-head d-flex justify-content-between">
                    <div class="col-lg-8 col-md-12 col-sm-12 ">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                    data-bs-target="#home-tab-pane" type="button" role="tab"
                                    aria-controls="home-tab-pane" aria-selected="true">Home</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                                    data-bs-target="#profile-tab-pane" type="button" role="tab"
                                    aria-controls="profile-tab-pane" aria-selected="false">Profile</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab"
                                    data-bs-target="#contact-tab-pane" type="button" role="tab"
                                    aria-controls="contact-tab-pane" aria-selected="false">Contact</button>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="notify-options d-flex">
                            <i class="fa-solid fa-filter fa-3x"></i>
                            <i class="fa-solid fa-gear fa-3x"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="notify-content">
                        <div class="notify-btns">
                            <div class="row justify-content-center">
                                <div class="col-lg-4 col-sm-12">
                                    <div class="read-btn">
                                        <button>mark as read</button>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-12">
                                    <div class="read-btn">
                                        <button>mark as read</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="notify-tabs">
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                                    .
                                </div>
                                <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                                    <div class="notify-main">
                                        <div class="first d-flex">
                                            <div class="image pl-2">
                                                <img src="<?php echo e(asset('/assets/images/Avatar.png')); ?>" alt="kc" >
                                            </div>
                                            <div class="notify-title">
                                                <p class="px-2">Lois Griffin commented in 🐶 Take Brian on a walk</p>
                                                <div class="notify-file d-flex px-2">
                                                    <img src="<?php echo e(asset('/assets/images/dropbox.png')); ?>" alt="kc" >
                                                    <p class="pl-2">Resources_ Product_Growth_Org Design....</p>
                                                </div>
                                                <p class="notify-time text-secondary mt-2">3 months ago</p>
                                            </div>
                                        </div>
                                      </div>
                                </div>
                                <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">...</div>
                                <div class="tab-pane fade" id="disabled-tab-pane" role="tabpanel" aria-labelledby="disabled-tab" tabindex="0">...</div>
                              </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kc-autoconnect-laravel\resources\views/user/screens/notification-view.blade.php ENDPATH**/ ?>